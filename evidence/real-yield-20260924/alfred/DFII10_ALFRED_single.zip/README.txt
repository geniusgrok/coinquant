-------------------------------------------------------------------
Series ID: DFII10
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org/series?seid=DFII10
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
Output Format: Observations by Vintage Date, New and Revised
Observations Only
File Created: 2026-09-24 1:14 PM CDT
-------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------------  ---------------  -------------
Title                                                                                                                          Real-Time Start  Real-Time End
Market Yield on U.S. Treasury Securities at 10-Year Constant Maturity,                                                         2019-07-01       Current
Quoted on an Investment Basis, Inflation-Indexed
Source
Board of Governors of the Federal Reserve System (US)                                                                          2005-10-12       Current
Release
H.15 Selected Interest Rates                                                                                                   2005-10-12       Current
Units
Percent                                                                                                                        2005-10-12       Current
Frequency
Daily                                                                                                                          2005-10-12       Current
Seasonal Adjustment
Not Seasonally Adjusted                                                                                                        2005-10-12       Current
Notes
For further information regarding treasury constant maturity data,                                                             2019-07-01       2025-01-06
please refer to the H.15 Statistical Release notes
(https://www.federalreserve.gov/releases/h15/default.htm) and the
Treasury Yield Curve Methodology
(https://home.treasury.gov/policy-issues/financing-the-government/interest-rate-statistics/treasury-yield-curve-methodology).
-----------------------------------------------------------------------------------------------------------------------------  ---------------  -------------

Vintage Dates Specified:
----------
2020-01-02
----------

